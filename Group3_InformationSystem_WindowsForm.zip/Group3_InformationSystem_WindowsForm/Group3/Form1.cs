﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.Common;

namespace Group3
{
    public partial class Form1 : Form
    {
        private OleDbConnection phoneConn;
        private OleDbCommand oleDbCmd = new OleDbCommand();
        private string connParam = @"Provider = Microsoft.Jet.OLEDB.4.0; Data Source = 
            C:\Users\asus®\Documents\Visual Studio 2017\Projects\Group3\Group3\PhoneSpec_db.mdb";

        public Form1()
        {
            phoneConn = new OleDbConnection(connParam);
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            phoneConn.Open();
            oleDbCmd.Connection = phoneConn;
            //RETRIEVE
            oleDbCmd.CommandText = "INSERT INTO tblPhoneInfo (PhoneName, Brand, Dimensions, Color, ScreenSize, Processor, RAM" +
                ", InternalStorage, RearCamera, FrontCamera, OperatingSystem, WarrantyPeriod) values " + "('" + this.textBox1.Text + 
                "','" + this.comboBox1.Text + "','" + this.comboBox2.Text + "','" + this.comboBox3.Text + "','" + this.comboBox4.Text + 
                "','" + this.comboBox7.Text + "','" + this.comboBox6.Text + "','" + this.comboBox5.Text + "','" + this.comboBox8.Text + 
                "','" + this.comboBox9.Text + "','" + this.comboBox11.Text + "','" + this.comboBox12.Text + "')";
            int temp = oleDbCmd.ExecuteNonQuery();
            if (temp > 0)

            {
                textBox1.Text = null;
                comboBox1.Text = null;
                comboBox2.Text = null;
                comboBox3.Text = null;
                comboBox4.Text = null;
                comboBox7.Text = null;
                comboBox6.Text = null;
               comboBox5.Text = null;
                comboBox8.Text = null;
                 comboBox9.Text = null;
                 comboBox11.Text = null;
                comboBox12.Text = null;

                MessageBox.Show("record successfully added!");
            }
            else
            {
                MessageBox.Show("record failed added!");

            }
            phoneConn.Close();

        
    }

        private void button2_Click(object sender, EventArgs e)
        {
           

           

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'phoneSpec_dbDataSet5.tblPhoneInfo' table. You can move, or remove it, as needed.
            this.tblPhoneInfoTableAdapter5.Fill(this.phoneSpec_dbDataSet5.tblPhoneInfo);
            
            
            

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

       

        private void label30_Click(object sender, EventArgs e)
        {

        }

       

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            

                dataGridView1.DataSource = null;
                dataGridView1.Rows.Clear();
                dataGridView1.Refresh();

                OleDbDataAdapter dAdapter = new OleDbDataAdapter("SELECT * FROM  tblPhoneInfo", connParam);
                OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("UPDATE * FROM tblPhoneInfo", connParam);
                OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

                DataTable dataTable = new DataTable();
                DataSet ds = new DataSet();

                dAdapter.Fill(dataTable);

                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    dataGridView1.Rows.Add(dataTable.Rows[i][0], dataTable.Rows[i][1], dataTable.Rows[i][2]
                        , dataTable.Rows[i][3], dataTable.Rows[i][4], dataTable.Rows[i][5], dataTable.Rows[i][6]
                        , dataTable.Rows[i][7], dataTable.Rows[i][8], dataTable.Rows[i][9], dataTable.Rows[i][10]
                        , dataTable.Rows[i][1], dataTable.Rows[i][12]);

            }

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            comboBox4.Text = "";
            comboBox5.Text = "";
            comboBox6.Text = "";
            comboBox7.Text = "";
            comboBox8.Text = "";
            comboBox9.Text = "";
            comboBox11.Text = "";
            comboBox12.Text = "";
        }
    }
}
