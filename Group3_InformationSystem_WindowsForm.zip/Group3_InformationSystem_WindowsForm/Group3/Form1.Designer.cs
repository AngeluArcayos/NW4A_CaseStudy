﻿namespace Group3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.submit = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.phoneSpec_dbDataSet = new Group3.PhoneSpec_dbDataSet();
            this.tblPhoneInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblPhoneInfoTableAdapter = new Group3.PhoneSpec_dbDataSetTableAdapters.tblPhoneInfoTableAdapter();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.phoneSpec_dbDataSet1 = new Group3.PhoneSpec_dbDataSet1();
            this.tblPhoneInfoBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tblPhoneInfoTableAdapter1 = new Group3.PhoneSpec_dbDataSet1TableAdapters.tblPhoneInfoTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dimensionsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.screenSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.processorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rAMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.internalStorageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rearCameraDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.frontCameraDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.operatingSystemDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.warrantyPeriodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblPhoneInfoBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.phoneSpec_dbDataSet5 = new Group3.PhoneSpec_dbDataSet5();
            this.tblPhoneInfoBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.phoneSpec_dbDataSet3 = new Group3.PhoneSpec_dbDataSet3();
            this.phoneSpec_dbDataSet2 = new Group3.PhoneSpec_dbDataSet2();
            this.tblPhoneInfoBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.tblPhoneInfoTableAdapter2 = new Group3.PhoneSpec_dbDataSet2TableAdapters.tblPhoneInfoTableAdapter();
            this.btnView = new System.Windows.Forms.Button();
            this.tblPhoneInfoTableAdapter3 = new Group3.PhoneSpec_dbDataSet3TableAdapters.tblPhoneInfoTableAdapter();
            this.phoneSpec_dbDataSet4 = new Group3.PhoneSpec_dbDataSet4();
            this.tblPhoneInfoBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.tblPhoneInfoTableAdapter4 = new Group3.PhoneSpec_dbDataSet4TableAdapters.tblPhoneInfoTableAdapter();
            this.tblPhoneInfoTableAdapter5 = new Group3.PhoneSpec_dbDataSet5TableAdapters.tblPhoneInfoTableAdapter();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.phoneSpec_dbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPhoneInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneSpec_dbDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPhoneInfoBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPhoneInfoBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneSpec_dbDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPhoneInfoBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneSpec_dbDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneSpec_dbDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPhoneInfoBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneSpec_dbDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPhoneInfoBindingSource4)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(135, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Phone Name";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(242, 62);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(121, 20);
            this.textBox1.TabIndex = 0;
            // 
            // submit
            // 
            this.submit.Location = new System.Drawing.Point(528, 255);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(104, 48);
            this.submit.TabIndex = 7;
            this.submit.Text = "SAVE";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.button1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Minion Pro", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(64, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(250, 22);
            this.label8.TabIndex = 22;
            this.label8.Text = "Essential Phone detail specifications";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(131, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 23;
            this.label1.Text = "GENERAL";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(135, 94);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "Brand Compatibility";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Samsung",
            "Oppo",
            "Lenovo",
            "Vivo",
            "Acer",
            "Asus",
            "Nokia",
            "Apple"});
            this.comboBox1.Location = new System.Drawing.Point(242, 91);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(135, 148);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 13);
            this.label13.TabIndex = 32;
            this.label13.Text = "Color";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(131, 167);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 13);
            this.label14.TabIndex = 33;
            this.label14.Text = "DISPLAY";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(135, 195);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(104, 13);
            this.label15.TabIndex = 34;
            this.label15.Text = "Screen Size (inches)";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Gold",
            "Rose Gold",
            "Black",
            "White",
            "Red"});
            this.comboBox3.Location = new System.Drawing.Point(242, 145);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 3;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "4.0",
            "5.0",
            "5.71",
            "7.2"});
            this.comboBox4.Location = new System.Drawing.Point(242, 192);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(131, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 40;
            this.label4.Text = "HARDWARE";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(135, 238);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 41;
            this.label5.Text = "Processor";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(135, 296);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(80, 13);
            this.label17.TabIndex = 44;
            this.label17.Text = "Internal storage";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(136, 267);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(31, 13);
            this.label18.TabIndex = 45;
            this.label18.Text = "RAM";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "4GB",
            "8GB",
            "16GB",
            "32GB",
            "64GB",
            "128GB"});
            this.comboBox5.Location = new System.Drawing.Point(242, 289);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(121, 21);
            this.comboBox5.TabIndex = 46;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "3GB",
            "4GB",
            "5GB",
            "8GB"});
            this.comboBox6.Location = new System.Drawing.Point(242, 262);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(121, 21);
            this.comboBox6.TabIndex = 6;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "MTK X23 Deca-core 2.3GHz",
            "Octa-core 1.4 GHz Cortex-A53",
            "Quad-core 1.2 GHz Cortex-A53",
            "1.8GHz Qualcomm Snapdragon 808 hexa-core"});
            this.comboBox7.Location = new System.Drawing.Point(242, 235);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(121, 21);
            this.comboBox7.TabIndex = 5;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(545, 46);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 13);
            this.label19.TabIndex = 49;
            this.label19.Text = "CAMERA";
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "16MP",
            "20MP",
            "23MP",
            "24MP",
            "26MP"});
            this.comboBox8.Location = new System.Drawing.Point(656, 62);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(121, 21);
            this.comboBox8.TabIndex = 51;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(549, 65);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(68, 13);
            this.label20.TabIndex = 50;
            this.label20.Text = "Rear camera";
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "5MP",
            "8MP",
            "10MP",
            "21MP",
            "24MP"});
            this.comboBox9.Location = new System.Drawing.Point(656, 89);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(121, 21);
            this.comboBox9.TabIndex = 53;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(549, 92);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(69, 13);
            this.label21.TabIndex = 52;
            this.label21.Text = "Front camera";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(545, 117);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(76, 13);
            this.label22.TabIndex = 54;
            this.label22.Text = "SOFTWARE";
            // 
            // comboBox11
            // 
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "Android Phone",
            "Windows Phone",
            "iOS"});
            this.comboBox11.Location = new System.Drawing.Point(656, 137);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(121, 21);
            this.comboBox11.TabIndex = 56;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(549, 140);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(90, 13);
            this.label24.TabIndex = 55;
            this.label24.Text = "Operating System";
            // 
            // comboBox12
            // 
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Items.AddRange(new object[] {
            "1 year",
            "2 years",
            "5 years"});
            this.comboBox12.Location = new System.Drawing.Point(656, 192);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(121, 21);
            this.comboBox12.TabIndex = 79;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(549, 195);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(83, 13);
            this.label32.TabIndex = 78;
            this.label32.Text = "Warranty Period";
            // 
            // phoneSpec_dbDataSet
            // 
            this.phoneSpec_dbDataSet.DataSetName = "PhoneSpec_dbDataSet";
            this.phoneSpec_dbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblPhoneInfoBindingSource
            // 
            this.tblPhoneInfoBindingSource.DataMember = "tblPhoneInfo";
            this.tblPhoneInfoBindingSource.DataSource = this.phoneSpec_dbDataSet;
            // 
            // tblPhoneInfoTableAdapter
            // 
            this.tblPhoneInfoTableAdapter.ClearBeforeFill = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(135, 121);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 13);
            this.label11.TabIndex = 27;
            this.label11.Text = "Dimensions (mm)";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "141.50 x 71.10 x 7.80",
            "150 x 76 x 8.6",
            "153.6 x 76.5 x 9.15",
            "151.1 x 74.2 x 7.5"});
            this.comboBox2.Location = new System.Drawing.Point(242, 118);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 2;
            // 
            // phoneSpec_dbDataSet1
            // 
            this.phoneSpec_dbDataSet1.DataSetName = "PhoneSpec_dbDataSet1";
            this.phoneSpec_dbDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblPhoneInfoBindingSource1
            // 
            this.tblPhoneInfoBindingSource1.DataMember = "tblPhoneInfo";
            this.tblPhoneInfoBindingSource1.DataSource = this.phoneSpec_dbDataSet1;
            // 
            // tblPhoneInfoTableAdapter1
            // 
            this.tblPhoneInfoTableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.phoneNameDataGridViewTextBoxColumn,
            this.brandDataGridViewTextBoxColumn,
            this.dimensionsDataGridViewTextBoxColumn,
            this.colorDataGridViewTextBoxColumn,
            this.screenSizeDataGridViewTextBoxColumn,
            this.processorDataGridViewTextBoxColumn,
            this.rAMDataGridViewTextBoxColumn,
            this.internalStorageDataGridViewTextBoxColumn,
            this.rearCameraDataGridViewTextBoxColumn,
            this.frontCameraDataGridViewTextBoxColumn,
            this.operatingSystemDataGridViewTextBoxColumn,
            this.warrantyPeriodDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblPhoneInfoBindingSource5;
            this.dataGridView1.Location = new System.Drawing.Point(7, 365);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(913, 265);
            this.dataGridView1.TabIndex = 82;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // phoneNameDataGridViewTextBoxColumn
            // 
            this.phoneNameDataGridViewTextBoxColumn.DataPropertyName = "PhoneName";
            this.phoneNameDataGridViewTextBoxColumn.HeaderText = "PhoneName";
            this.phoneNameDataGridViewTextBoxColumn.Name = "phoneNameDataGridViewTextBoxColumn";
            // 
            // brandDataGridViewTextBoxColumn
            // 
            this.brandDataGridViewTextBoxColumn.DataPropertyName = "Brand";
            this.brandDataGridViewTextBoxColumn.HeaderText = "Brand";
            this.brandDataGridViewTextBoxColumn.Name = "brandDataGridViewTextBoxColumn";
            // 
            // dimensionsDataGridViewTextBoxColumn
            // 
            this.dimensionsDataGridViewTextBoxColumn.DataPropertyName = "Dimensions";
            this.dimensionsDataGridViewTextBoxColumn.HeaderText = "Dimensions";
            this.dimensionsDataGridViewTextBoxColumn.Name = "dimensionsDataGridViewTextBoxColumn";
            // 
            // colorDataGridViewTextBoxColumn
            // 
            this.colorDataGridViewTextBoxColumn.DataPropertyName = "Color";
            this.colorDataGridViewTextBoxColumn.HeaderText = "Color";
            this.colorDataGridViewTextBoxColumn.Name = "colorDataGridViewTextBoxColumn";
            // 
            // screenSizeDataGridViewTextBoxColumn
            // 
            this.screenSizeDataGridViewTextBoxColumn.DataPropertyName = "ScreenSize";
            this.screenSizeDataGridViewTextBoxColumn.HeaderText = "ScreenSize";
            this.screenSizeDataGridViewTextBoxColumn.Name = "screenSizeDataGridViewTextBoxColumn";
            // 
            // processorDataGridViewTextBoxColumn
            // 
            this.processorDataGridViewTextBoxColumn.DataPropertyName = "Processor";
            this.processorDataGridViewTextBoxColumn.HeaderText = "Processor";
            this.processorDataGridViewTextBoxColumn.Name = "processorDataGridViewTextBoxColumn";
            // 
            // rAMDataGridViewTextBoxColumn
            // 
            this.rAMDataGridViewTextBoxColumn.DataPropertyName = "RAM";
            this.rAMDataGridViewTextBoxColumn.HeaderText = "RAM";
            this.rAMDataGridViewTextBoxColumn.Name = "rAMDataGridViewTextBoxColumn";
            // 
            // internalStorageDataGridViewTextBoxColumn
            // 
            this.internalStorageDataGridViewTextBoxColumn.DataPropertyName = "InternalStorage";
            this.internalStorageDataGridViewTextBoxColumn.HeaderText = "InternalStorage";
            this.internalStorageDataGridViewTextBoxColumn.Name = "internalStorageDataGridViewTextBoxColumn";
            // 
            // rearCameraDataGridViewTextBoxColumn
            // 
            this.rearCameraDataGridViewTextBoxColumn.DataPropertyName = "RearCamera";
            this.rearCameraDataGridViewTextBoxColumn.HeaderText = "RearCamera";
            this.rearCameraDataGridViewTextBoxColumn.Name = "rearCameraDataGridViewTextBoxColumn";
            // 
            // frontCameraDataGridViewTextBoxColumn
            // 
            this.frontCameraDataGridViewTextBoxColumn.DataPropertyName = "FrontCamera";
            this.frontCameraDataGridViewTextBoxColumn.HeaderText = "FrontCamera";
            this.frontCameraDataGridViewTextBoxColumn.Name = "frontCameraDataGridViewTextBoxColumn";
            // 
            // operatingSystemDataGridViewTextBoxColumn
            // 
            this.operatingSystemDataGridViewTextBoxColumn.DataPropertyName = "OperatingSystem";
            this.operatingSystemDataGridViewTextBoxColumn.HeaderText = "OperatingSystem";
            this.operatingSystemDataGridViewTextBoxColumn.Name = "operatingSystemDataGridViewTextBoxColumn";
            // 
            // warrantyPeriodDataGridViewTextBoxColumn
            // 
            this.warrantyPeriodDataGridViewTextBoxColumn.DataPropertyName = "WarrantyPeriod";
            this.warrantyPeriodDataGridViewTextBoxColumn.HeaderText = "WarrantyPeriod";
            this.warrantyPeriodDataGridViewTextBoxColumn.Name = "warrantyPeriodDataGridViewTextBoxColumn";
            // 
            // tblPhoneInfoBindingSource5
            // 
            this.tblPhoneInfoBindingSource5.DataMember = "tblPhoneInfo";
            this.tblPhoneInfoBindingSource5.DataSource = this.phoneSpec_dbDataSet5;
            // 
            // phoneSpec_dbDataSet5
            // 
            this.phoneSpec_dbDataSet5.DataSetName = "PhoneSpec_dbDataSet5";
            this.phoneSpec_dbDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblPhoneInfoBindingSource3
            // 
            this.tblPhoneInfoBindingSource3.DataMember = "tblPhoneInfo";
            this.tblPhoneInfoBindingSource3.DataSource = this.phoneSpec_dbDataSet3;
            // 
            // phoneSpec_dbDataSet3
            // 
            this.phoneSpec_dbDataSet3.DataSetName = "PhoneSpec_dbDataSet3";
            this.phoneSpec_dbDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // phoneSpec_dbDataSet2
            // 
            this.phoneSpec_dbDataSet2.DataSetName = "PhoneSpec_dbDataSet2";
            this.phoneSpec_dbDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblPhoneInfoBindingSource2
            // 
            this.tblPhoneInfoBindingSource2.DataMember = "tblPhoneInfo";
            this.tblPhoneInfoBindingSource2.DataSource = this.phoneSpec_dbDataSet2;
            // 
            // tblPhoneInfoTableAdapter2
            // 
            this.tblPhoneInfoTableAdapter2.ClearBeforeFill = true;
            // 
            // btnView
            // 
            this.btnView.Location = new System.Drawing.Point(648, 255);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(105, 48);
            this.btnView.TabIndex = 8;
            this.btnView.Text = "VIEW";
            this.btnView.UseVisualStyleBackColor = true;
            this.btnView.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // tblPhoneInfoTableAdapter3
            // 
            this.tblPhoneInfoTableAdapter3.ClearBeforeFill = true;
            // 
            // phoneSpec_dbDataSet4
            // 
            this.phoneSpec_dbDataSet4.DataSetName = "PhoneSpec_dbDataSet4";
            this.phoneSpec_dbDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblPhoneInfoBindingSource4
            // 
            this.tblPhoneInfoBindingSource4.DataMember = "tblPhoneInfo";
            this.tblPhoneInfoBindingSource4.DataSource = this.phoneSpec_dbDataSet4;
            // 
            // tblPhoneInfoTableAdapter4
            // 
            this.tblPhoneInfoTableAdapter4.ClearBeforeFill = true;
            // 
            // tblPhoneInfoTableAdapter5
            // 
            this.tblPhoneInfoTableAdapter5.ClearBeforeFill = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(769, 255);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 48);
            this.button2.TabIndex = 83;
            this.button2.Text = "CANCEL";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // Form1
            // 
            this.AcceptButton = this.btnView;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(932, 677);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnView);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.comboBox12);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.comboBox11);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.comboBox9);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.comboBox8);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.comboBox7);
            this.Controls.Add(this.comboBox6);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "Mobile Phone Information System";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.phoneSpec_dbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPhoneInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneSpec_dbDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPhoneInfoBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPhoneInfoBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneSpec_dbDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPhoneInfoBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneSpec_dbDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneSpec_dbDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPhoneInfoBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneSpec_dbDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPhoneInfoBindingSource4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Label label32;
        private PhoneSpec_dbDataSet phoneSpec_dbDataSet;
        private System.Windows.Forms.BindingSource tblPhoneInfoBindingSource;
        private PhoneSpec_dbDataSetTableAdapters.tblPhoneInfoTableAdapter tblPhoneInfoTableAdapter;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox2;
        private PhoneSpec_dbDataSet1 phoneSpec_dbDataSet1;
        private System.Windows.Forms.BindingSource tblPhoneInfoBindingSource1;
        private PhoneSpec_dbDataSet1TableAdapters.tblPhoneInfoTableAdapter tblPhoneInfoTableAdapter1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private PhoneSpec_dbDataSet2 phoneSpec_dbDataSet2;
        private System.Windows.Forms.BindingSource tblPhoneInfoBindingSource2;
        private PhoneSpec_dbDataSet2TableAdapters.tblPhoneInfoTableAdapter tblPhoneInfoTableAdapter2;
        private System.Windows.Forms.Button btnView;
        private PhoneSpec_dbDataSet3 phoneSpec_dbDataSet3;
        private System.Windows.Forms.BindingSource tblPhoneInfoBindingSource3;
        private PhoneSpec_dbDataSet3TableAdapters.tblPhoneInfoTableAdapter tblPhoneInfoTableAdapter3;
        private PhoneSpec_dbDataSet4 phoneSpec_dbDataSet4;
        private System.Windows.Forms.BindingSource tblPhoneInfoBindingSource4;
        private PhoneSpec_dbDataSet4TableAdapters.tblPhoneInfoTableAdapter tblPhoneInfoTableAdapter4;
        private PhoneSpec_dbDataSet5 phoneSpec_dbDataSet5;
        private System.Windows.Forms.BindingSource tblPhoneInfoBindingSource5;
        private PhoneSpec_dbDataSet5TableAdapters.tblPhoneInfoTableAdapter tblPhoneInfoTableAdapter5;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn brandDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dimensionsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn screenSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn processorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rAMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn internalStorageDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rearCameraDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn frontCameraDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn operatingSystemDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn warrantyPeriodDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button2;
    }
}

