﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string connetionString = null;
        OleDbConnection connection;
        OleDbDataAdapter oledbAdapter = new OleDbDataAdapter();
        string sql = null;
        connetionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Mary Grace Ocampo\Desktop\SumerianTechContactDiary\SumerianTechContactDiary\ContactDiary.accdb";
        connection = new OleDbConnection(connetionString);
        sql = "delete from Contact where Fullname = '" + TextBox1.Text + "'";
        try
        {
            connection.Open();
            oledbAdapter.DeleteCommand = connection.CreateCommand();
            oledbAdapter.DeleteCommand.CommandText = sql;
            oledbAdapter.DeleteCommand.ExecuteNonQuery();
            Label1.Text = "Contact Deleted !! Please refresh the page to see changes";
        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }
    }
}
