﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnBrowse_Click(object sender, EventArgs e)
    {

    }

    protected void btnNew_Click(object sender, EventArgs e)
    {
        string connetionString = null;
        OleDbConnection connection;
        OleDbDataAdapter oledbAdapter = new OleDbDataAdapter();
        string sql = null;
        connetionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Mary Grace Ocampo\Desktop\SumerianTechContactDiary\SumerianTechContactDiary\ContactDiary.accdb";
        connection = new OleDbConnection(connetionString);
        sql = "insert into Contact(Fullname,Address,PhoneNumber,Email) values('" + txtName.Text + "','" + txtAddress.Text + "','" + txtPhoneNo.Text + "','" + txtEmail.Text + "') ";
        try
        {
            connection.Open();
            oledbAdapter.DeleteCommand = connection.CreateCommand();
            oledbAdapter.DeleteCommand.CommandText = sql;
            oledbAdapter.DeleteCommand.ExecuteNonQuery();
            Label4.Text = "Contact Added !! ";
        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }
    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        string connetionString = null;
        OleDbConnection connection;
        OleDbDataAdapter oledbAdapter = new OleDbDataAdapter();
        string sql = null;
        connetionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C: \Users\Mary Grace Ocampo\Desktop\SumerianTechContactDiary\SumerianTechContactDiary\ContactDiary.accdb";
        connection = new OleDbConnection(connetionString);
        sql = "insert into Contact(Fullname,Address,PhoneNuber,Email) values('" + txtName.Text + "','" + txtAddress.Text + "','" + txtPhoneNo.Text + "','" + txtEmail.Text + "') ";
        try
        {
            connection.Open();
            oledbAdapter.DeleteCommand = connection.CreateCommand();
            oledbAdapter.DeleteCommand.CommandText = sql;
            oledbAdapter.DeleteCommand.ExecuteNonQuery();
            Label4.Text = "Contact Added !! ";
        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }
    }

    protected void txtEmail_TextChanged(object sender, EventArgs e)
    {

    }
}