﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hotel
{
    public partial class Form1 : Form
    {

      //  private OleDbConnection phoneConn = new OleDbConnection();
        private OleDbCommand oleDbCmd = new OleDbCommand();
        OleDbConnection connParam = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Danny\Documents\Visual Studio 2015\HotelInformation.mdb");




        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txtHours.Text != "")
            {
             
                connParam.Open();
                string query = "INSERT INTO hotelinformation (RoomNo, RoomType, Floor, Description, Duration, Price, Hours) values ('" + this.txtRoomNum.Text + "','" + this.txtRoomType.Text + "','" + this.txtFloor.Text + "','" + this.txtDescription.Text + "','" + this.txtDuration.Text + "','" + this.txtPrice.Text + "','" + this.txtHours.Text + "')";
                OleDbDataAdapter sda = new OleDbDataAdapter(query, connParam);
                DataTable dtbl = new DataTable();
                sda.Fill(dtbl);

                OleDbCommand cmd = new OleDbCommand(query, connParam);
                
                int temp = cmd.ExecuteNonQuery();
                if (temp > 0)
            {
                txtDescription.Text = null;
                txtDuration.Text = null;
                txtFloor.Text = null;
                txtHours.Text = null;
                txtPrice.Text = null;
                txtRoomNum.Text = null;
                txtRoomType.Text = null;

                MessageBox.Show("record successfully added!");
            }
            else
            {
                MessageBox.Show("record failed added!");

            }
                connParam.Close();
            } else
            {
                MessageBox.Show("Required ALL fields");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView.DataSource = null;
            dataGridView.Rows.Clear();
            dataGridView.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("SELECT * FROM  hotelinformation", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("UPDATE * FROM hotelinformation", connParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView.Rows.Add(dataTable.Rows[i][0], dataTable.Rows[i][1], dataTable.Rows[i][2]
                    , dataTable.Rows[i][3], dataTable.Rows[i][4], dataTable.Rows[i][5], dataTable.Rows[i][6]
                    , dataTable.Rows[i][7]);

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hotelInformationDataSet.hotelinformation' table. You can move, or remove it, as needed.
            this.hotelinformationTableAdapter.Fill(this.hotelInformationDataSet.hotelinformation);
        }

		private void label1_Click(object sender, EventArgs e)
		{

		}
	}
}
